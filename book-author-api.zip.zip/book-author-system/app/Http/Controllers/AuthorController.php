<?php

namespace App\Http\Controllers;

use App\Models\Author;
use Illuminate\Http\Request;

class AuthorController extends Controller
{
    // Get all authors
    public function index()
    {
        return response()->json(Author::with('books')->get());
    }

    // Create new author
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email|unique:authors,email',
            'bio' => 'nullable|string'
        ]);

        $author = Author::create($request->all());

        return response()->json([
            'message' => 'Author created successfully',
            'data' => $author
        ], 201);
    }

    // Get single author
    public function show($id)
    {
        $author = Author::with('books')->findOrFail($id);

        return response()->json($author);
    }

    // Update author
    public function update(Request $request, $id)
    {
        $author = Author::findOrFail($id);

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|email',
            'bio' => 'nullable|string'
        ]);

        $author->update($request->all());

        return response()->json([
            'message' => 'Author updated successfully',
            'data' => $author
        ]);
    }

    // Delete author
    public function destroy($id)
    {
        $author = Author::findOrFail($id);
        $author->delete();

        return response()->json([
            'message' => 'Author deleted successfully'
        ]);
    }
}