<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\AuthorController;
use App\Http\Controllers\BookController;

Route::get('/', function () {
    return response()->json([
        'message' => 'Author & Book API',
        'version' => '1.0',
        'endpoints' => [
            'GET /api/authors',
            'GET /api/books'
        ]
    ]);
});