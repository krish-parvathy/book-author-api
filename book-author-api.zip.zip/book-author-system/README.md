# Author & Book API (Laravel)

This project is a RESTful API built using Laravel to manage Authors and Books. It demonstrates CRUD operations and a one-to-many relationship between Authors and Books where one author can have multiple books. The API provides JSON responses and includes endpoints to create, view, update, and delete both authors and books.

Tech Stack: PHP, Laravel, MySQL.

API Endpoints: Authors → GET /api/authors, POST /api/authors, GET /api/authors/{id}, PUT /api/authors/{id}, DELETE /api/authors/{id}. Books → GET /api/books, POST /api/books, GET /api/books/{id}, PUT /api/books/{id}, DELETE /api/books/{id}.

Setup Instructions: Install dependencies using `composer install`, copy the environment file using `cp .env.example .env`, configure the database in the `.env` file, generate the application key using `php artisan key:generate`, run migrations using `php artisan migrate`, and start the development server using `php artisan serve`. After starting the server, open `http://127.0.0.1:8000/api` to access the API.

Example Response: When calling GET /api/authors, the API returns author data along with their books in JSON format.

Author: Parvathy Prakash
